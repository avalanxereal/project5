const http = require("http"), fs = require("fs"), path = require("path");
const ROOT = __dirname, DIR = path.join(ROOT, "feedbacks"), PORT = process.env.PORT || 3000;
const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".png": "image/png", ".svg": "image/svg+xml" };
const local = r => ["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(r.socket.remoteAddress);
http.createServer((req, res) => {
    const send = (c, b, t = "application/json") => { res.writeHead(c, { "Content-Type": t }); res.end(b); };
    try {
        const u = new URL(req.url, "http://x");
        if (u.pathname === "/api/feedback" && req.method === "POST") {
            let b = "";
            req.on("data", d => { b += d; if (b.length > 10000)
                req.destroy(); });
            req.on("end", () => {
                try {
                    const j = JSON.parse(b), o = { n: String(j.n || "").slice(0, 60), t: String(j.t || "").slice(0, 30), s: String(j.s || "").slice(0, 2000), at: Date.now() };
                    if (!o.s.trim())
                        return send(400, '{"error":"pesan kosong"}');
                    fs.mkdirSync(DIR, { recursive: true });
                    fs.writeFileSync(path.join(DIR, o.at + "-" + Math.random().toString(36).slice(2, 7) + ".json"), JSON.stringify(o, null, 2));
                    send(200, '{"ok":true}');
                }
                catch (e) {
                    send(400, '{"error":"tidak valid"}');
                }
            });
            return;
        }
        if (u.pathname === "/api/feedbacks") {
            if (!local(req))
                return send(403, '{"error":"hanya dari localhost"}');
            let a = [];
            try {
                a = fs.readdirSync(DIR).filter(f => f.endsWith(".json")).sort().reverse().map(f => JSON.parse(fs.readFileSync(path.join(DIR, f))));
            }
            catch (e) { }
            return send(200, JSON.stringify(a));
        }
        const p = decodeURIComponent(u.pathname);
        let f = path.join(ROOT, path.normalize(p));
        if (!f.startsWith(ROOT) || /(^|[\\/])(feedbacks|server\.js)/.test(p))
            return send(404, "Tidak ditemukan", "text/plain");
        if (fs.statSync(f).isDirectory())
            f = path.join(f, "index.html");
        send(200, fs.readFileSync(f), MIME[path.extname(f)] || "application/octet-stream");
    }
    catch (e) {
        send(404, "Tidak ditemukan", "text/plain");
    }
}).listen(PORT, () => console.log("Buka http://localhost:" + PORT));
ation/octet-stream");
    }
    catch (e) {
        send(404, "Tidak ditemukan", "text/plain");
    }
}).listen(PORT, () => console.log("Buka http://localhost:" + PORT));
