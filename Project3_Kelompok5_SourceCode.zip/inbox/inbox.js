(async () => {
    let a = [];
    const src = document.getElementById("src"), ls = document.getElementById("ls");
    try {
        const r = await fetch("/api/feedbacks");
        if (!r.ok)
            throw 0;
        a = await r.json();
        src.textContent = "Dibaca dari folder feedbacks/ di server (" + a.length + " masukan).";
    }
    catch (e) {
        try {
            a = JSON.parse(localStorage.getItem("lf_feedback")) || [];
        }
        catch (x) { }
        a.reverse();
        src.textContent = "Server belum berjalan (jalankan: node server.js). Menampilkan masukan yang tersimpan di peramban ini (" + a.length + ").";
    }
    a.forEach(f => {
        const d = document.createElement("div");
        d.className = "card";
        const h = document.createElement("b");
        h.textContent = f.t + " – " + f.n;
        const p = document.createElement("p");
        p.textContent = f.s;
        const s = document.createElement("small");
        s.textContent = new Date(f.at).toLocaleString("id-ID");
        d.append(h, p, s);
        ls.append(d);
    });
    document.getElementById("dl").onclick = () => { const l = document.createElement("a"); l.href = URL.createObjectURL(new Blob([JSON.stringify(a, null, 2)], { type: "application/json" })); l.download = "feedback.json"; l.click(); };
})();
