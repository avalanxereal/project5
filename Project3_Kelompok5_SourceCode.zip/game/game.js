const U = LF.need();
if (!U)
    throw new Error("belum login");
const UP = Object.assign({ store: 0, speed: 0 }, U.save.up), CAP = 6 + 2 * UP.store, SPD = Math.max(3, 8 - UP.speed), CD = 30;
const T = [["Tas ransel", "🎒", 1], ["Botol minum", "🧴", 0], ["Kotak pensil", "✏️", 1], ["HP", "📱", 0], ["Tumbler", "☕", 0], ["Payung", "☂️", 0], ["Jaket", "🧥", 0]];
const C = ["merah", "biru", "hijau", "kuning", "hitam", "pink"], CH = { merah: "#ff6b6b", biru: "#6bb6ff", hijau: "#5fdc8b", kuning: "#ffd23f", hitam: "#8a82a8", pink: "#ff9bd0" };
const CLUES = {
    "Tas ransel": ["gantungan bintang di resleting", "label nama di bagian dalam", "stiker di saku depan", "gantungan boneka di tali tas"],
    "Kotak pensil": ["stiker kecil di tutupnya", "label nama di bagian dalam", "gambar bintang di bagian luar", "resletingnya ada gantungan kecil"],
    "Botol minum": ["stiker di badan botol", "goresan kecil di tutup", "nama tertulis di bagian bawah", "tutupnya berwarna berbeda"],
    "Tumbler": ["stiker di bagian luar", "goresan kecil dekat tutup", "nama tertulis di bagian bawah", "ada gantungan kecil di tutup"],
    "Payung": ["pegangan bergambar", "pita kecil di tali pengikat", "nama tertulis di gagangnya", "ujung salah satu rusuknya berbeda"],
    "Jaket": ["label nama di bagian dalam", "stiker pada kantong kecil", "gantungan kecil di resleting", "ada tambalan di bagian siku"],
    "HP": ["stiker di casing belakang", "casing bergambar bintang", "ada gantungan kecil di casing", "goresan kecil di sudut casing"]
};
const CONTENTS = {
    "Tas ransel": ["buku IPA & penggaris", "buku gambar & krayon", "kalkulator & buku catatan", "bekal & sapu tangan"],
    "Kotak pensil": ["2 pensil & penghapus", "pulpen, penggaris & rautan", "pensil warna & penghapus", "spidol kecil & penggaris"]
};
const RM = { Perpustakaan: ["lib", "📚", "#6bb6ff"], Kantin: ["kan", "🍜", "#ffa94d"], Lapangan: ["lap", "⚽", "#4cd37b"], "Lab IPA": ["lab", "🔬", "#b9a2ff"], Kelas: ["kel", "✏️", "#ff8cc0"] }, ROOMS = Object.keys(RM);
const SK = ["#ffd8b0", "#f0b98a", "#c98b5e", "#8d5a3b"], HR = ["#3b2a1d", "#1d1d1d", "#d9822b", "#7a3b86"], SH = ["#ff6fa5", "#4aa3ff", "#4cd37b", "#ffb020", "#a78bfa", "#ff7a45"];
const R = a => a[Math.random() * a.length | 0], $ = id => document.getElementById(id), low = s => s.toLowerCase();
const fmt = m => String(m / 60 | 0).padStart(2, "0") + "." + String(m % 60).padStart(2, "0");
const fig = (l, w) => `<svg viewBox="0 0 90 140" width="${w}" style="stroke:var(--ink);stroke-width:4;stroke-linejoin:round"><path d="M10 140C10 98 28 84 45 84S80 98 80 140Z" fill="${l.sh}"/><circle cx="45" cy="50" r="30" fill="${l.sk}"/><path d="M14 48Q16 14 45 17Q74 14 76 48Q60 32 45 36Q30 32 14 48Z" fill="${l.hr}"/><circle cx="34" cy="55" r="3.5" fill="#2b2140" stroke="none"/><circle cx="56" cy="55" r="3.5" fill="#2b2140" stroke="none"/><path d="M37 67Q45 74 53 67" fill="none"/></svg>`;
const SAVE_KEY = "lf_game_" + (LF.me() || "guest");
const S = { d: U.save.day || 1, clock: 540, shelf: [], hid: [], q: [], sched: [], cur: null, sel: null, paused: false, busy: false, over: false, job: null, cool: {}, line: ["", ""], prev: null, st: {}, nid: 1 };
function saveProgress() {
    if (S.over) {
        localStorage.removeItem(SAVE_KEY);
        return;
    }
    try {
        localStorage.setItem(SAVE_KEY, JSON.stringify({ ...S, paused: true, busy: false }));
    }
    catch (e) { }
}
function restoreProgress() {
    try {
        const raw = localStorage.getItem(SAVE_KEY);
        if (!raw)
            return false;
        const old = JSON.parse(raw);
        if (!old || old.over || !old.st || !Array.isArray(old.sched))
            return false;
        Object.assign(S, old, { paused: true, busy: false });
        return true;
    }
    catch (e) {
        return false;
    }
}
const brk = () => S.clock >= 720 && S.clock < 780;
const live = c => c.real && (S.shelf.some(x => x.id === c.id) || S.hid.some(x => x.id === c.id));
const put = (el, h) => { if (el._h !== h) {
    el._h = h;
    el.innerHTML = h;
} };
function startDay() {
    const n = Math.min(5 + S.d, 16), nF = Math.round(n * Math.min(.25 + S.d * .02, .5)), used = {}, items = [];
    Object.assign(S, { clock: 540, shelf: [], hid: [], q: [], sched: [], cur: null, sel: null, busy: false, over: false, job: null, cool: {} });
    S.st = { ok: 0, total: n, found: 0, hidTotal: 0, t: [] };
    for (let i = 0; i < n - nF; i++) {
        let ti, c;
        do {
            ti = R(T);
            c = R(C);
        } while (used[ti[0] + c]);
        used[ti[0] + c] = 1;
        const it = { id: S.nid++, t: ti[0], e: ti[1], box: ti[2], c, m: R(CLUES[ti[0]]), k: ti[2] ? R(CONTENTS[ti[0]]) : "", loc: R(ROOMS) };
        items.push(it);
        if (S.shelf.length < CAP && Math.random() < .4)
            S.shelf.push(it);
        else {
            S.hid.push(it);
            S.st.hidTotal++;
        }
    }
    const lk = () => ({ sk: R(SK), hr: R(HR), sh: R(SH) }), cl = items.map(it => ({ real: 1, ...it, look: lk() }));
    for (let i = 0; i < nF; i++) {
        const it = R(items), free = C.filter(x => !items.some(j => j.t === it.t && j.c === x)), look = Math.random() < .6 || !free.length;
        cl.push({ real: 0, id: -1, t: it.t, e: it.e, box: it.box, c: look ? it.c : R(free), m: R(CLUES[it.t].filter(x => x !== it.m)), k: it.box ? R(CONTENTS[it.t].filter(x => x !== it.k)) : "", loc: R(ROOMS), look: lk() });
    }
    cl.sort(() => Math.random() - .5);
    cl.forEach((c, i) => c.at = i ? 540 + Math.floor((i + Math.random() * .8) * 330 / n) : 540);
    S.sched = cl;
    $("fl").textContent = "Klik ruangan untuk mencari. Ruangan bisa dicari lagi 30 menit kemudian.";
    arrive();
}
function arrive() {
    while (S.sched.length && S.sched[0].at <= S.clock)
        S.q.push(S.sched.shift());
    if (!S.cur && !S.busy && !S.paused && !S.over && !S.job) {
        if (S.q.length) {
            S.cur = S.q.shift();
            S.sel = null;
            S.line = ["Selamat datang, ada yang bisa dibantu?", "Saya kehilangan " + low(S.cur.t) + " " + S.cur.c + " di " + S.cur.loc + "."];
        }
        else
            S.line = ["Belum ada siswa.", "Cari barang di peta sekolah."];
    }
    draw();
}
function tick() {
    if (S.paused || S.over)
        return;
    S.clock++;
    if (S.job && --S.job.left <= 0)
        finishSearch();
    if (S.clock >= 900)
        return endDay();
    arrive();
}
function draw() {
    saveProgress();
    $("d").textContent = S.d;
    $("clk").textContent = fmt(S.clock);
    $("qn").textContent = S.q.length;
    document.body.classList.toggle("rest", brk());
    $("ob").textContent = S.line[0];
    $("sb").textContent = S.line[1];
    put($("qs"), S.q.length ? `<div class="bub sm">Saya juga kehilangan barang.</div><div class="qf">${S.q.slice(0, 3).map(s => fig(s.look, 52)).join("")}</div>+${S.q.length} antre` : "");
    put($("cf"), S.cur ? fig(S.cur.look, 120) : "");
    const can = S.cur && !S.busy && !S.paused && !S.over && !S.job;
    document.querySelectorAll("#menu button").forEach(b => b.disabled = !can);
    $("cap").textContent = S.shelf.length + "/" + CAP;
    put($("sh"), S.shelf.map(x => `<button class="item" style="background:${CH[x.c]}${S.sel && S.sel.id === x.id ? ";outline:4px solid #2b2140;outline-offset:2px" : ""}" onclick="pick(${x.id})" ${S.busy || S.paused || S.job ? "disabled" : ""}><span>${x.e}</span>${low(x.t)}</button>`).join("") || "<i>Rak kosong. Cari barang di peta!</i>");
    const s = S.sel;
    put($("ib"), s ? `<b>${s.box ? "Isi tasnya:" : "Ciri barang:"}</b>${s.box ? s.k : s.m}` : "<i>Klik barang di rak untuk melihat isi atau cirinya.</i>");
    put($("map"), ROOMS.map(r => {
        const [a, e, col] = RM[r], cd = (S.cool[r] || 0) > S.clock, act = S.job && S.job.r === r;
        return `<button class="room${act ? " act" : ""}" style="grid-area:${a};background:${col}" onclick="search('${r}')" ${S.job || S.paused || S.over || S.busy || cd ? "disabled" : ""}>${S.cur && S.cur.loc === r ? '<span class="pin">📍</span>' : ""}<span class="em">${e}</span>${r}<small>${act ? "Mencari…" : cd ? "Siap lagi " + fmt(S.cool[r]) : "Siap dicari"}</small></button>`;
    }).join("") + `<div class="room lobi" style="grid-area:lob">🏫 Lobi<small>Rak ${S.shelf.length}/${CAP}</small></div>`);
    $("map").style.setProperty("--p", (S.job ? 100 * (1 - S.job.left / S.job.total) : 0) + "%");
}
function pick(id) { if (S.busy || S.paused || S.job)
    return; LF.sfx("click"); S.sel = S.sel && S.sel.id === id ? null : S.shelf.find(x => x.id === id); draw(); }
function need() { if (S.sel)
    return true; S.line[0] = "Pilih barang di rak dulu."; draw(); return false; }
function search(r) {
    if (S.job || S.paused || S.over || S.busy || (S.cool[r] || 0) > S.clock)
        return;
    LF.sfx("click");
    S.prev = S.line;
    S.job = { r, left: SPD, total: SPD };
    S.line = ["Sebentar, saya cari di " + r + "…", S.cur ? "Baik, saya tunggu." : "…"];
    draw();
}
function finishSearch() {
    const r = S.job.r, here = S.hid.filter(x => x.loc === r), take = here.slice(0, Math.max(0, CAP - S.shelf.length));
    S.job = null;
    S.cool[r] = S.clock + CD;
    S.hid = S.hid.filter(x => !take.includes(x));
    S.shelf.push(...take);
    S.st.found += take.length;
    $("fl").textContent = take.length ? "Ditemukan di " + r + ": " + take.map(x => low(x.t) + " " + x.c).join(", ") : here.length ? "Rak penuh! Masih ada barang di " + r + ". Cari lagi nanti." : "Tidak ada barang di " + r + ".";
    LF.sfx(take.length ? "found" : "bad");
    S.line = S.cur ? S.prev : ["Belum ada siswa.", "Cari barang di peta sekolah."];
}
function show() {
    if (!need())
        return;
    const s = S.sel, c = S.cur;
    let r;
    LF.sfx("click");
    if (s.t !== c.t)
        r = "Bukan, punya saya " + low(c.t) + ".";
    else if (s.c !== c.c)
        r = "Warnanya bukan itu. Punya saya warna " + c.c + ".";
    else
        r = "Wah, sepertinya itu punya saya!";
    S.line = ["Apakah barangnya seperti ini? (" + low(s.t) + " " + s.c + ")", r];
    draw();
}
function proof() { const c = S.cur; LF.sfx("click"); S.line = ["Apa Anda punya bukti?", c.box ? "Di dalamnya ada " + c.k + "." : "Ada " + c.m + " di barang saya."]; draw(); }
function done(ok, msg) {
    S.busy = true;
    S.st.t.push(Math.max(S.clock - S.cur.at, 0));
    if (ok)
        S.st.ok++;
    S.line = [S.line[0], msg];
    LF.sfx(ok ? "ok" : "bad");
    const t = $("toast");
    t.className = "toast " + (ok ? "good" : "bad");
    t.textContent = ok ? "BENAR" : "SALAH";
    setTimeout(() => { S.busy = false; S.cur = null; S.sel = null; t.className = "toast"; S.line = ["", ""]; arrive(); }, 1800);
    draw();
}
function give() {
    if (!need())
        return;
    const s = S.sel, c = S.cur, good = live(c) && s.id === c.id;
    if (good || !c.real)
        S.shelf = S.shelf.filter(x => x.id !== s.id);
    done(good && !brk(), brk() ? "Eh, ini kan jam istirahat…" : good ? "Benar, ini punya saya. Terima kasih!" : c.real ? "Bukan ini barang saya!" : "Terima kasih! (Padahal itu bukan miliknya.)");
}
function none() {
    const l = live(S.cur);
    done(!l && !brk(), brk() ? "Ini jam istirahat, seharusnya tidak dilayani!" : l ? "Tapi barang saya dilaporkan hilang di sini…" : "Oh begitu, saya cari di tempat lain.");
}
function later() { brk() ? done(true, "Oh, lagi istirahat ya. Saya kembali nanti.") : done(false, "Yah, saya sudah antre dari tadi…"); }
function endDay() {
    S.over = true;
    const st = S.st;
    const avg = st.t.length ? st.t.reduce((a, b) => a + b, 0) / st.t.length : 60, sp = Math.max(0, Math.min(1, (60 - avg) / 40)), acc = st.ok / st.total;
    const score = Math.round(50 * acc + 20 * (st.hidTotal ? st.found / st.hidTotal : 1) + 30 * sp * acc);
    const g = score >= 95 ? "S" : score >= 85 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : score >= 45 ? "D" : score >= 30 ? "E" : "F";
    const coins = st.ok * 8 + st.found * 5 + { S: 50, A: 35, B: 25, C: 15, D: 8, E: 3, F: 0 }[g];
    LF.save(u => { u.save.day = S.d + 1; u.save.coins = (u.save.coins || 0) + coins; u.save.hist.push({ d: S.d, g, score, ok: st.ok, total: st.total, found: st.found, hid: st.hidTotal, avg: Math.round(avg) }); u.save.hist = u.save.hist.slice(-60); });
    $("dt").textContent = "Day " + S.d + " selesai";
    $("gr").textContent = g;
    $("gr").className = "gr g" + g;
    $("gs").innerHTML = `Skor ${score}/100<br>Siswa dilayani benar: ${st.ok}/${st.total}<br>Barang ditemukan: ${st.found}/${st.hidTotal}<br>Rata-rata waktu per siswa: ${Math.round(avg)} menit<br><b>+${coins} koin 🪙</b>`;
    LF.sfx("found");
    draw();
    $("dlg").showModal();
}
function nextDay() { $("dlg").close(); S.d++; startDay(); }
function pause() { if (S.over || S.paused)
    return; S.paused = true; draw(); if (!$("pz").open)
    $("pz").showModal(); }
$("pb").onclick = pause;
$("pz").onclose = () => { S.paused = false; saveProgress(); arrive(); };
document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
        if (!S.over) {
            S.paused = true;
            saveProgress();
        }
    }
    else if (S.paused && !S.over && !$("pz").open) {
        $("pz").showModal();
        draw();
    }
});
window.addEventListener("pagehide", () => { if (!S.over) {
    S.paused = true;
    saveProgress();
} });
$("dlg").addEventListener("cancel", e => e.preventDefault());
LF.bgm();
if (restoreProgress()) {
    draw();
    $("pz").showModal();
}
else
    startDay();
setInterval(tick, 1000);
